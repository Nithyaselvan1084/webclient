package com.example.webclientcollege;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CollegeController {

	@GetMapping("/college/{id}")
	public ResponseEntity<CollegeEntity> getcollege(@PathVariable int id) {
		CollegeEntity c1 = new CollegeEntity();
		c1.setId(1);
		c1.setCollegename("Abc");
		return new ResponseEntity<CollegeEntity>(c1, HttpStatus.OK);
	}
}
