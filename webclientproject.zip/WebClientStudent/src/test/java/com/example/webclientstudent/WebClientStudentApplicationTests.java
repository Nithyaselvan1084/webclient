package com.example.webclientstudent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebClientStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
