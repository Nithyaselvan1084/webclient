package com.example.webclientstudent;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

@RestController
public class StudentController {
	@Autowired
	private WebClient.Builder webclient;

	@GetMapping("/student/{id}")
	public ResponseEntity<ResponseData> student(@PathVariable int id) {
		ResponseData response = new ResponseData();
		StudentEntity s1 = new StudentEntity();
		s1.setId(1);
		s1.setName("selva");

		CollegeEntity c1 = webclient.build().get().uri("http://localhost:8082/college/" + id).retrieve()
				.bodyToMono(CollegeEntity.class).block();
		response.setCollegeentity(c1); 
		response.setStudententity(s1);
		return new ResponseEntity<ResponseData>(response, HttpStatus.OK);
	}
//	@GetMapping("/student/{id}")
//	public ResponseEntity<StudentEntity>student(@PathVariable int id){
//		StudentEntity s1=new StudentEntity();
//		s1.setId(1);
//		s1.setName("selva");
//		return new ResponseEntity<StudentEntity>(s1,HttpStatus.OK);
//	}

}
