package com.example.webclientstudent;

public class CollegeEntity {
	private int id;
	private String collegename;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCollegename() {
		return collegename;
	}
	public void setCollegename(String collegename) {
		this.collegename = collegename;
	}
	@Override
	public String toString() {
		return "CollegeEntity [id=" + id + ", collegename=" + collegename + "]";
	}
	

}
