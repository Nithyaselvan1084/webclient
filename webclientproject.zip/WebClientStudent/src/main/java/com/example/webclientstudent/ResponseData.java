package com.example.webclientstudent;

public class ResponseData {
	private CollegeEntity collegeentity;
	private StudentEntity studententity;
	
	public CollegeEntity getCollegeentity() {
		return collegeentity;
	}
	public void setCollegeentity(CollegeEntity collegeentity) {
		this.collegeentity = collegeentity;
	}
	public StudentEntity getStudententity() {
		return studententity;
	}
	public void setStudententity(StudentEntity studententity) {
		this.studententity = studententity;
	}
	@Override
	public String toString() {
		return "ResponseData [collegeentity=" + collegeentity + ", studententity=" + studententity + "]";
	}
	

}
